package DemoWork;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String arrList[] = {"a","e","i","o","u"};
		for(int i=0;i<arrList.length;i++)
		{
			System.out.println(arrList[i]);
		
		}
		System.out.println("\n");
		
		int arrList1[] = {1,2,3,4,5,6,7};
		for(int j=0;j<arrList1.length;j++)
		{
			System.out.println(arrList1[j]);
			
	
		}
		System.out.println("\n");
		
		
		/*Scanner sc=new Scanner(System.in);
		int l=sc.nextInt();
	    String arr[]=new String[l];
		for(int i=0;i<l;i++)
		{
			arr[i]=sc.next();
		}
		for(String s: arr)
		{
			System.out.println(s);
		}
		*/
		


	}
}
