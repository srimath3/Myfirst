package constructor;
import java.util.ArrayList;

public interface Employee {
	 public ArrayList<String> fetchEmployeeDetails(double salary);

}
